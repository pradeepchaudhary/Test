//                  
// 	ClearBox Language File (JavaScript)
//

var

	CB_NavTextPrv='precedentul',					// text of previous image
	CB_NavTextNxt='următorul',					// text of next image
	CB_NavTextFull='imaginea în marimea originală',			// text of original size (only at pictures)
	CB_NavTextOpen='deschide într-o fereastra nouă',		// text of open content in a new browser window
	CB_NavTextDL='descarcă',					// text of download picture or any other content
	CB_NavTextClose='închide fereastra',				// text of close CB
	CB_NavTextStart='pornire slideshow',				// text of start slideshow
	CB_NavTextStop='oprire slideshow',				// text of stop slideshow
	CB_NavTextRotR='rotirea imagini cu 90 de grade spre dreapta',	// text of rotation right
	CB_NavTextRotL='rotirea imagini cu 90 de grade spre stânga'	// text of rotation left
	CB_NavTextReady='clearbox is ready'		// text of clearbox ready

;