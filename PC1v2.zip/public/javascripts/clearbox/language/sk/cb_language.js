//                  
// 	ClearBox Language File (JavaScript)
//	lang - slovakia

var

  CB_NavTextPrv='Predch&aacute;dzaj&uacute;ci obr&aacute;zok',				// text of previous image
  CB_NavTextNxt='Nasleduj&uacute;ci obr&aacute;zok',					// text of next image
  CB_NavTextFull='Zobrazi&#357; obr&aacute;zok v plnej ve&#318;kosti',			// text of original size (only at pictures)
  CB_NavTextOpen='Otvorte prehliada&#269;',						// text of open content in a new browser window
  CB_NavTextDL='Stiahnutie',								// text of download picture or any other content
  CB_NavTextClose='Zavrie&#357; okno',							// text of close CB
  CB_NavTextStart='Spusti&#357; prezent&aacute;ciu',					// text of start slideshow
  CB_NavTextStop='Zastavi&#357; prezent&aacute;ciu',					// text of stop slideshow
  CB_NavTextRotR='Oto&#269;enie obr&aacute;zku vpravo o 90 stup&#328;ov',		// text of rotation right
  CB_NavTextRotL='Oto&#269;enie obr&aacute;zku o 90 stup&#328;ov do&#318;ava'		// text of rotation left
  CB_NavTextReady='clearbox is ready'		// text of clearbox ready

;