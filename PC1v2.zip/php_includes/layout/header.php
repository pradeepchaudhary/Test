<html>
    <head>
        <meta charset="UTF-8">
        <title>PC1v2 Information Management System</title>
        
        <link href="stylesheets/base_style.css" rel="stylesheet" type="text/css"/>
        <link rel='shortcut icon' href='../images/logo.ico'>
        
    </head>
    <body>
        <header>
            <img id="logo" src='../images/logo.png' class="logo"/>
            <h1>PC1v2 Information Management System</h1>
            <!--<h1>Why waste an hour every time when just a moment is  sufficient ???</h1>-->
        </header>
